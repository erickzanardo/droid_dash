/* -*- c-set-style: "K&R"; c-basic-offset: 8 -*-
 *
 * This file is part of PRoot.
 *
 * Copyright (C) 2015 STMicroelectronics
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 */

#ifndef SYSCALL_H
#define SYSCALL_H

#include <limits.h>     /* PATH_MAX, */

#include "tracee/tracee.h"
#include "tracee/reg.h"

/**
 * State passed along with the READLINK_PROC_FD event, that is, the
 * result of a readlink(2) against "/proc/@pid/fd/@fd".
 */
struct readlink_proc_fd_state {
	/* Process the descriptor belongs to.  */
	pid_t pid;

	/* Descriptor whose content was read.  */
	int fd;

	/* Host path the kernel reported, ie. the path of the file the
	 * descriptor refers to.  An extension may overwrite it with
	 * another host path -- the buffer is PATH_MAX bytes long -- and
	 * set @substituted accordingly.  */
	char *host_path;

	/* Whether @host_path was replaced by an extension.  */
	bool substituted;
};

extern int get_sysarg_path(const Tracee *tracee, char path[PATH_MAX], Reg reg);
extern int set_sysarg_path(Tracee *tracee, const char path[PATH_MAX], Reg reg);
extern int set_sysarg_data(Tracee *tracee, const void *tracer_ptr, word_t size, Reg reg);

extern void translate_syscall(Tracee *tracee);
extern int  translate_syscall_enter(Tracee *tracee);
extern void translate_syscall_exit(Tracee *tracee);
extern bool is_voided_syscall(const Tracee *tracee, RegVersion version);

extern void handle_netlink_reply_exit(Tracee *tracee, word_t syscall_number);

extern void apply_emulated_mount(Tracee *tracee);
extern void apply_emulated_pivot_root(Tracee *tracee);
extern void apply_emulated_umount(Tracee *tracee);

#endif /* SYSCALL_H */
